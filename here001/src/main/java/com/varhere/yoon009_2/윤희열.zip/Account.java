package com.varhere.yoon009_2;
/**
 * 2*5*7 jump lucky 윤희열 
 * Account는 SavingsAccount와 CheckingAccount의 공통적인 부분을 
 * 묶어내기 위해서 만들었다.
 * @author here
 *
 */

public class Account {
	protected String accountNum;
	protected double balance;
	
	public void deposite(double amount) {
		this.balance += amount;
	}
}
